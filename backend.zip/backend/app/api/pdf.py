from fastapi import APIRouter, File, UploadFile
from fastapi.responses import JSONResponse

from app.services.pdf_extractor import (
    PDFExtractionError,
    PDFExtractor,
)
from app.validators.pdf_validator import (
    PDFValidationError,
    PDFValidator,
)


router = APIRouter(
    prefix="/pdf",
    tags=["PDF"],
)


@router.post("/extract")
async def extract_pdf(
    file: UploadFile = File(...),
):
    """
    Upload a PDF and extract text page-by-page.
    """

    # -----------------------------
    # 1. Validate PDF
    # -----------------------------
    try:
        file_data = await PDFValidator.validate(file)

    except PDFValidationError as exc:
        status_code = 400

        if exc.code == "FILE_TOO_LARGE":
            status_code = 413

        return JSONResponse(
            status_code=status_code,
            content={
                "success": False,
                "error": {
                    "code": exc.code,
                    "message": exc.message,
                },
            },
        )

    # -----------------------------
    # 2. Extract PDF
    # -----------------------------
    try:
        extraction_result = PDFExtractor.extract(file_data)

    except PDFExtractionError as exc:
        status_code = 422

        if exc.code == "EXTRACTION_FAILED":
            status_code = 500

        return JSONResponse(
            status_code=status_code,
            content={
                "success": False,
                "error": {
                    "code": exc.code,
                    "message": exc.message,
                },
            },
        )

    # -----------------------------
    # 3. Build response
    # -----------------------------
    file_size = len(file_data)

    size_mb = round(
        file_size / (1024 * 1024),
        3,
    )

    response = {
        "success": True,
        "message": "PDF processed successfully.",
        "file": {
            "filename": file.filename,
            "size_bytes": file_size,
            "size_mb": size_mb,
            "page_count": extraction_result["page_count"],
        },
        "extraction": {
            "method": "pymupdf",
            "text_extracted": extraction_result[
                "text_extracted"
            ],
        },
        "data": extraction_result["pages"],
    }

    return response


@router.get("/status")
async def pdf_status():
    return {
        "status": "ready",
        "service": "pdf-extractor",
    }