from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.pdf import router as pdf_router
from app.config import settings


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "API for validating PDF files and "
        "extracting text page-by-page."
    ),
)


# ---------------------------------
# CORS
# ---------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------
# API routes
# ---------------------------------

app.include_router(
    pdf_router,
    prefix=settings.api_prefix,
)


# ---------------------------------
# Root
# ---------------------------------

@app.get("/")
async def root():
    return {
        "success": True,
        "service": settings.app_name,
        "version": settings.app_version,
        "status": "running",
    }


# ---------------------------------
# Health
# ---------------------------------

@app.get("/health")
async def health():
    return {
        "success": True,
        "status": "healthy",
    }

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)